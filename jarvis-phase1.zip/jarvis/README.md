# JARVIS

Voice-first personal AI assistant (FastAPI + Next.js, Tauri desktop, PWA mobile).
See `docs/ARCHITECTURE.md` and `docs/IMPLEMENTATION_PLAN.md`.

**Status: Phase 1 (foundation).** No AI, voice or tools yet — see "What works" below.

## Requirements
- Python 3.11+, Node 20+ (tested: Python 3.13, Node 22)
- Later phases: Rust (Tauri), ~1 GB disk for speech models
- An Anthropic API key (paid, pay-per-token) is needed from Phase 2 on.

## Setup
```bash
cp .env.example .env              # add ANTHROPIC_API_KEY when you reach Phase 2
cp frontend/.env.example frontend/.env.local
make setup                        # venv + pip install, npm install
make migrate                      # creates backend/jarvis.db
```
If `DATABASE_URL` is relative (`sqlite:///./jarvis.db`), run backend commands from `backend/`.

## Run (two terminals)
```bash
make backend    # http://localhost:8000  (API docs: /docs)
make frontend   # http://localhost:3000
```

## Test
```bash
make test       # pytest, vitest, tsc, next build
```

## What works (Phase 1)
- `GET /api/health` — DB check, whether a Claude key is configured (never the key), voice marked "not implemented".
- JSON logs with request IDs; uniform error envelope `{"error": {code, message, request_id}}`.
- SQLAlchemy + Alembic; first migration creates `audit_log`.
- Web UI: shows live backend status, polls every 15 s, Recheck button.

from fastapi.testclient import TestClient

from app.core.config import Settings, get_settings
from app.main import create_app


def client(**overrides) -> TestClient:
    app = create_app()
    app.dependency_overrides[get_settings] = lambda: Settings(**overrides)
    return TestClient(app)


def test_health_ok_without_key():
    r = client(anthropic_api_key=None).get("/api/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "ok"
    comps = {c["name"]: c for c in body["components"]}
    assert comps["database"]["ok"] is True
    assert comps["claude_api"]["ok"] is False
    assert comps["voice"]["ok"] is False


def test_health_never_leaks_key():
    secret = "sk-ant-test-SECRET-123"
    r = client(anthropic_api_key=secret).get("/api/health")
    assert secret not in r.text
    comps = {c["name"]: c for c in r.json()["components"]}
    assert comps["claude_api"]["ok"] is True


def test_request_id_header_and_404_shape():
    r = client().get("/api/nope", headers={"x-request-id": "abc123"})
    assert r.status_code == 404
    assert r.headers["x-request-id"] == "abc123"
    assert r.json()["error"]["code"] == "http_error"
    assert r.json()["error"]["request_id"] == "abc123"

from alembic import command
from alembic.config import Config
from sqlalchemy import create_engine, inspect


def test_upgrade_and_downgrade(tmp_path):
    url = f"sqlite:///{tmp_path / 't.db'}"
    cfg = Config("alembic.ini")
    cfg.set_main_option("sqlalchemy.url", url)
    cfg.attributes["skip_logging"] = True
    command.upgrade(cfg, "head")
    assert "audit_log" in inspect(create_engine(url)).get_table_names()
    command.downgrade(cfg, "base")
    assert "audit_log" not in inspect(create_engine(url)).get_table_names()

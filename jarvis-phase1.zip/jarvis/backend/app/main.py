"""FastAPI application factory."""
import logging
import time
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from app import __version__
from app.api.routes import health
from app.core.config import get_settings
from app.core.errors import register_error_handlers
from app.core.logging import configure_logging

log = logging.getLogger("jarvis")


def create_app() -> FastAPI:
    settings = get_settings()
    configure_logging(settings.log_level)

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        log.info("startup", extra={"path": settings.environment})
        if not settings.anthropic_configured:
            log.warning("ANTHROPIC_API_KEY is not set; AI features will be unavailable")
        yield
        log.info("shutdown")

    app = FastAPI(title=settings.app_name, version=__version__, lifespan=lifespan)

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.middleware("http")
    async def request_context(request: Request, call_next):
        request.state.request_id = request.headers.get("x-request-id") or uuid.uuid4().hex[:12]
        start = time.perf_counter()
        response = await call_next(request)
        response.headers["x-request-id"] = request.state.request_id
        log.info(
            "request",
            extra={
                "request_id": request.state.request_id,
                "path": request.url.path,
                "status": response.status_code,
                "duration_ms": round((time.perf_counter() - start) * 1000, 1),
            },
        )
        return response

    register_error_handlers(app)
    app.include_router(health.router, prefix="/api")
    return app


app = create_app()

"""Typed application settings loaded from environment / .env."""
from functools import lru_cache
from pathlib import Path

from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT_DIR = Path(__file__).resolve().parents[3]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=(ROOT_DIR / ".env", ROOT_DIR / "backend" / ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    app_name: str = "JARVIS"
    environment: str = Field(default="development", pattern="^(development|test|production)$")
    log_level: str = "INFO"

    database_url: str = f"sqlite:///{ROOT_DIR / 'backend' / 'jarvis.db'}"

    # Never sent to clients. Only its presence is reported.
    anthropic_api_key: SecretStr | None = None
    anthropic_model: str = "claude-sonnet-5-5"

    cors_origins: list[str] = ["http://localhost:3000", "tauri://localhost"]

    @property
    def anthropic_configured(self) -> bool:
        return bool(self.anthropic_api_key and self.anthropic_api_key.get_secret_value().strip())


@lru_cache
def get_settings() -> Settings:
    return Settings()

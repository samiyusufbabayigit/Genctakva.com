from typing import Literal

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app import __version__
from app.core.config import Settings, get_settings
from app.db.session import get_db, ping

router = APIRouter(tags=["system"])

Status = Literal["ok", "degraded"]


class ComponentStatus(BaseModel):
    name: str
    ok: bool
    detail: str


class HealthResponse(BaseModel):
    status: Status
    app: str
    version: str
    environment: str
    components: list[ComponentStatus]


@router.get("/health", response_model=HealthResponse)
def health(db: Session = Depends(get_db), settings: Settings = Depends(get_settings)) -> HealthResponse:
    db_ok = ping(db)
    components = [
        ComponentStatus(name="database", ok=db_ok, detail="reachable" if db_ok else "unreachable"),
        ComponentStatus(
            name="claude_api",
            ok=settings.anthropic_configured,
            detail="API key configured" if settings.anthropic_configured else "ANTHROPIC_API_KEY not set",
        ),
        ComponentStatus(name="voice", ok=False, detail="not implemented (Phase 4)"),
    ]
    return HealthResponse(
        status="ok" if db_ok else "degraded",
        app=settings.app_name,
        version=__version__,
        environment=settings.environment,
        components=components,
    )

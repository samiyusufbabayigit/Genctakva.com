"""Reserved for a later phase; see docs/IMPLEMENTATION_PLAN.md. Nothing here is wired up yet."""

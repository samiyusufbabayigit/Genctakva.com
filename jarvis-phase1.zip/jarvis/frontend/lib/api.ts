export type ComponentStatus = { name: string; ok: boolean; detail: string };

export type Health = {
  status: "ok" | "degraded";
  app: string;
  version: string;
  environment: string;
  components: ComponentStatus[];
};

export const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

export type HealthResult = { ok: true; data: Health } | { ok: false; error: string };

/** Fetch backend health with a timeout; never throws. */
export async function fetchHealth(
  fetcher: typeof fetch = fetch,
  baseUrl: string = API_URL,
  timeoutMs = 4000,
): Promise<HealthResult> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetcher(`${baseUrl}/api/health`, { signal: ctrl.signal, cache: "no-store" });
    if (!res.ok) return { ok: false, error: `Backend responded ${res.status}` };
    return { ok: true, data: (await res.json()) as Health };
  } catch (e) {
    const aborted = e instanceof Error && e.name === "AbortError";
    return { ok: false, error: aborted ? "Backend timed out" : "Backend unreachable" };
  } finally {
    clearTimeout(timer);
  }
}

export const COMPONENT_LABELS: Record<string, string> = {
  database: "Database",
  claude_api: "Claude API",
  voice: "Voice",
};

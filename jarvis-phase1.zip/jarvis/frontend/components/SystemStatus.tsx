"use client";

import { useCallback, useEffect, useState } from "react";
import { COMPONENT_LABELS, fetchHealth, type HealthResult } from "../lib/api";

const POLL_MS = 15000;

export default function SystemStatus() {
  const [result, setResult] = useState<HealthResult | null>(null);
  const [checking, setChecking] = useState(false);

  const check = useCallback(async () => {
    setChecking(true);
    setResult(await fetchHealth());
    setChecking(false);
  }, []);

  useEffect(() => {
    check();
    const id = setInterval(check, POLL_MS);
    return () => clearInterval(id);
  }, [check]);

  const online = result?.ok === true;

  return (
    <section className="panel" aria-live="polite">
      <header className="panel-head">
        <h2>System status</h2>
        <button className="btn" onClick={check} disabled={checking}>
          {checking ? "Checking…" : "Recheck"}
        </button>
      </header>

      <div className="row">
        <span className={`dot ${online ? "ok" : result ? "bad" : ""}`} />
        <span>Backend</span>
        <span className="muted">
          {result === null ? "checking…" : result.ok ? `v${result.data.version} · ${result.data.environment}` : result.error}
        </span>
      </div>

      {result?.ok &&
        result.data.components.map((c) => (
          <div className="row" key={c.name}>
            <span className={`dot ${c.ok ? "ok" : "warn"}`} />
            <span>{COMPONENT_LABELS[c.name] ?? c.name}</span>
            <span className="muted">{c.detail}</span>
          </div>
        ))}
    </section>
  );
}

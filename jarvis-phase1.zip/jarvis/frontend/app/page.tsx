import SystemStatus from "../components/SystemStatus";

export default function Home() {
  return (
    <main className="shell">
      <div className="brand">
        <div className="core" aria-hidden />
        <h1>J.A.R.V.I.S.</h1>
        <p className="muted">Foundation build · voice and chat arrive in later phases</p>
      </div>
      <SystemStatus />
    </main>
  );
}

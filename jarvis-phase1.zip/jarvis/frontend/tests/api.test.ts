import { describe, expect, it } from "vitest";
import { fetchHealth } from "../lib/api";

const health = {
  status: "ok", app: "JARVIS", version: "0.1.0", environment: "test",
  components: [{ name: "database", ok: true, detail: "reachable" }],
};

describe("fetchHealth", () => {
  it("returns data on 200", async () => {
    const f = (async () => new Response(JSON.stringify(health), { status: 200 })) as typeof fetch;
    const r = await fetchHealth(f, "http://x");
    expect(r).toEqual({ ok: true, data: health });
  });

  it("reports non-2xx status", async () => {
    const f = (async () => new Response("", { status: 503 })) as typeof fetch;
    expect(await fetchHealth(f, "http://x")).toEqual({ ok: false, error: "Backend responded 503" });
  });

  it("reports unreachable backend without throwing", async () => {
    const f = (async () => { throw new TypeError("fetch failed"); }) as typeof fetch;
    expect(await fetchHealth(f, "http://x")).toEqual({ ok: false, error: "Backend unreachable" });
  });

  it("times out", async () => {
    const f = ((_: RequestInfo | URL, init?: RequestInit) =>
      new Promise((_, rej) =>
        init?.signal?.addEventListener("abort", () => rej(new DOMException("x", "AbortError"))),
      )) as typeof fetch;
    expect(await fetchHealth(f, "http://x", 20)).toEqual({ ok: false, error: "Backend timed out" });
  });
});

# JARVIS — Architecture

Voice-first personal AI assistant for desktop (Tauri) and mobile (PWA).
One FastAPI backend holds every secret and every capability; clients are thin.

## 1. System overview

```
 ┌──────────────── Clients ────────────────┐
 │  Next.js web UI  ──►  PWA (iOS/Android) │
 │        └────────►  Tauri desktop shell  │
 └───────────────┬─────────────────────────┘
                 │  HTTPS (REST)  +  WebSocket (/ws/session)
 ┌───────────────▼──────────────────────────────────────────┐
 │ FastAPI backend                                          │
 │  api/        REST + WS routing, auth, validation         │
 │  ai/         Claude client, prompt, tool-use loop        │
 │  voice/      STT (faster-whisper) / TTS (Piper) providers│
 │  memory/     approved facts, search, edit/delete         │
 │  tools/      allowlisted registry, permissions, confirm  │
 │  core/       config, logging, errors, audit              │
 │  db/         SQLAlchemy engine/session, Alembic          │
 └───────┬───────────────┬───────────────┬──────────────────┘
         │               │               │
   SQLite/Postgres   Anthropic API   Playwright / local FS
                                    (only via tools/ registry)
```

## 2. Key decisions

| Decision | Choice | Why |
|---|---|---|
| Secrets | Backend `.env` only | Client bundles are public; the API key never leaves the server. |
| Transport | REST for CRUD, one WebSocket per conversation | Streaming tokens, audio chunks, status events and barge-in share one channel. |
| AI | Anthropic Messages API, official `anthropic` SDK, streaming + tool use | Requirement; tool use drives every action. |
| Model actions | Only via typed tools in an allowlisted registry | The model never gets a shell. Each tool declares `risk` (read / write / external) and a Pydantic input schema. |
| Confirmation | `external` and destructive tools pause and emit `confirm_required` over WS | User must approve deletes, sends, purchases. |
| STT / TTS | `SpeechToText` / `TextToSpeech` Protocols; faster-whisper and Piper default | Swappable (cloud providers later) without touching callers. |
| DB | SQLAlchemy 2.0 + Alembic; SQLite dev, `DATABASE_URL` switches to Postgres | No SQLite-only SQL; JSON stored as `JSON` type. |
| Untrusted content | Web pages / documents wrapped and labelled as data in prompts; never executed | Prompt-injection defence. |
| Audit | Every tool execution writes `audit_log` (who, tool, args digest, result, confirmation) | Accountability and debugging. |
| Kill switch | Global "emergency stop" flag checked before every tool call; per-permission revoke | Requirement. |

## 3. Conversation flow (target, Phases 2–4)

1. Client opens `/ws/session`, holds push-to-talk → streams audio frames.
2. `voice.stt` transcribes on release → `status: thinking`.
3. `ai` sends history + approved memory + tool schemas to Claude (streaming).
4. Tool call → `tools.registry` validates input, checks permission & kill switch,
   asks for confirmation if required, executes, writes audit row, returns result.
5. Text deltas → client; sentence chunks → `voice.tts` → audio frames → `status: speaking`.
6. User speaks/presses during playback → `interrupt` → TTS and generation cancelled.

WebSocket event types: `status`, `transcript`, `text_delta`, `audio_chunk`,
`tool_call`, `confirm_required`, `confirm_response`, `interrupt`, `error`.

## 4. Data model (grows per phase)

| Table | Phase | Purpose |
|---|---|---|
| `audit_log` | 1 | Executed actions |
| `conversations`, `messages` | 2 | Chat history |
| `memories` | 5 | User-approved facts (kind, content, source, approved_at) |
| `tasks`, `reminders` | 6 | Dashboard |
| `permissions`, `allowed_dirs`, `allowed_domains` | 7 | Tool access control |
| `workflows` | 7 | Saved automations |

## 5. Security model

- API key only in backend env; `/api/health` reports *whether* it is set, never its value.
- Single-user local deployment first; an access token (`JARVIS_ACCESS_TOKEN`) guards REST/WS before any non-localhost exposure (Phase 2).
- No `subprocess` with model-generated strings anywhere; CI grep check in Phase 9.
- File tools resolve real paths and reject anything outside user-selected directories (symlink-safe).
- Browser tools limited to an allowlist of domains and actions.
- No background microphone/screen monitoring: microphone opens only on push-to-talk.

## 6. External dependencies & cost

| Dependency | Paid? | Note |
|---|---|---|
| Anthropic API | **Yes, pay-per-token** | Separate from a Claude.ai subscription; needs a Console API key. |
| Web search (Phase 6) | Usually yes | Adapter interface; e.g. Brave/Tavily key, or Claude's server-side web search tool (billed per search). |
| faster-whisper, Piper | Free, local | Models downloaded once (~75 MB–1.5 GB for Whisper, ~60 MB per Piper voice). |
| Tauri build | Free | Needs Rust + platform SDKs on the build machine. |

## 7. Repository layout

```
jarvis/
├── docs/                 ARCHITECTURE.md, IMPLEMENTATION_PLAN.md
├── backend/
│   ├── app/
│   │   ├── main.py       app factory, lifespan, middleware
│   │   ├── core/         config, logging, errors
│   │   ├── api/          router + routes/
│   │   ├── db/           engine, session, Base
│   │   ├── models/       ORM models
│   │   ├── ai/ voice/ memory/ tools/   (later phases)
│   ├── alembic/          migrations
│   └── tests/
├── frontend/             Next.js (App Router) + TS, PWA later
│   ├── app/ components/ lib/ tests/
├── desktop/              Tauri shell (Phase 8)
├── .env.example
└── README.md
```

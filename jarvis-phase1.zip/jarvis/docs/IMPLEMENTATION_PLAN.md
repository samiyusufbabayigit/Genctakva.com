# Implementation plan

Each phase ends with passing tests and a runnable system.

| # | Phase | Deliverables | Done when |
|---|---|---|---|
| 1 | Foundation | Repo layout, config, logging, error handling, DB + Alembic, `audit_log`, `/api/health`, Next.js shell showing live backend status, tests, docs | `pytest`, `vitest`, `next build` pass; UI shows backend health |
| 2 | AI brain | `ai/` Claude client (streaming, retries, timeouts), system prompt, conversations/messages tables, `/ws/session` text chat, access token | Text chat streams from Claude end-to-end; tests mock the SDK |
| 3 | Dashboard UI | Command-center layout, audio visualizer, status states, chat panel, settings page | Every visible control works |
| 4 | Voice | STT/TTS Protocols, faster-whisper + Piper providers, push-to-talk, sentence-chunked TTS, interruption | Talk → hear reply; barge-in stops audio |
| 5 | Memory | `memories` table, propose-then-approve flow, search, edit/delete UI, injection into prompt | Only approved facts reach Claude |
| 6 | Tasks & research | Tasks/reminders CRUD + tools, web search adapter, citations | "Add a task", "research X" work by voice |
| 7 | Computer tools | Tool registry, permissions, confirmations, allowed dirs/domains, file search, Playwright navigation, audit view, emergency stop | Consequential actions always ask; kill switch blocks all tools |
| 8 | Packaging | PWA manifest + service worker, Tauri shell pointing at backend | Installable on phone; desktop binary builds |
| 9 | Hardening | E2E Playwright tests, security checks (no shell exec, secret scan), full docs | CI-style `make check` green |
